<?php
$pageTitle = "إضافة إعلان جديد";
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$pdo = Database::getInstance();
$errors = [];

// جلب البيانات الأولية
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order ASC")->fetchAll();
$states     = $pdo->query("SELECT * FROM states ORDER BY name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "رمز الحماية غير صالح.";
    }

    $title          = sanitize($_POST['title'] ?? '');
    $category_id    = filter_var($_POST['category_id'] ?? null, FILTER_VALIDATE_INT);
    $price          = filter_var($_POST['price'] ?? 0, FILTER_VALIDATE_FLOAT);
    $listing_type   = sanitize($_POST['listing_type'] ?? 'sale');
    $condition_type = sanitize($_POST['condition_type'] ?? 'used');
    $state_id       = filter_var($_POST['state_id'] ?? null, FILTER_VALIDATE_INT);
    $city_id        = filter_var($_POST['city_id'] ?? null, FILTER_VALIDATE_INT);
    $neighborhood_id= filter_var($_POST['neighborhood_id'] ?? null, FILTER_VALIDATE_INT);
    $custom_location= sanitize($_POST['custom_location'] ?? '');
    $description    = sanitize($_POST['description'] ?? '');
    $phone          = sanitize($_POST['phone'] ?? '');
    $whatsapp       = sanitize($_POST['whatsapp'] ?? '');

    // التحقق من صحة المدخلات
    if (empty($title)) $errors[] = "يرجى كتابة عنوان الإعلان.";
    if (!$category_id) $errors[] = "يرجى اختيار القسم الرئيسي.";
    if (!$state_id || !$city_id) $errors[] = "يرجى اختيار الولاية والمدينة.";
    if (empty($phone)) $errors[] = "يرجى إدخال رقم التواصل.";

    // معالجة وإدخال البيانات
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO listings 
            (user_id, category_id, title, description, price, listing_type, condition_type, state_id, city_id, neighborhood_id, custom_location, phone, whatsapp) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $inserted = $stmt->execute([
            $_SESSION['user_id'], $category_id, $title, $description, $price, 
            $listing_type, $condition_type, $state_id, $city_id, 
            $neighborhood_id ?: null, $custom_location ?: null, $phone, $whatsapp ?: $phone
        ]);

        if ($inserted) {
            $listing_id = $pdo->lastInsertId();

            // رفع الصور
            if (!empty($_FILES['images']['name'][0])) {
                $upload_dir = __DIR__ . '/uploads/listings/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }

                $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp'];
                $total_files = count($_FILES['images']['name']);

                for ($i = 0; $i < min($total_files, 5); $i++) { // الحد الأقصى 5 صور
                    $file_name = $_FILES['images']['name'][$i];
                    $tmp_name  = $_FILES['images']['tmp_name'][$i];
                    $file_ext  = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                    if (in_array($file_ext, $allowed_extensions)) {
                        $new_name = 'img_' . $listing_id . '_' . uniqid() . '.' . $file_ext;
                        if (move_uploaded_file($tmp_name, $upload_dir . $new_name)) {
                            $is_primary = ($i === 0) ? 1 : 0;
                            $img_stmt = $pdo->prepare("INSERT INTO listing_images (listing_id, image_path, is_primary) VALUES (?, ?, ?)");
                            $img_stmt->execute([$listing_id, $new_name, $is_primary]);
                        }
                    }
                }
            }

            redirect('listing-details.php?id=' . $listing_id);
        } else {
            $errors[] = "حدث خطأ أثناء حفظ الإعلان.";
        }
    }
}
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-body p-4">
                    <h4 class="fw-bold mb-4"><i class="text-warning me-2" data-lucide="plus-circle"></i>أضف إعلاناً جديداً</h4>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger py-2 mb-4">
                            <ul class="mb-0 ps-3">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

                        <!-- البيانات الأساسية -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">عنوان الإعلان *</label>
                            <input type="text" name="title" class="form-control" placeholder="مثال: تويوتا كورولا 2015 بحالة ممتازة" required>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">القسم الرئيسي *</label>
                                <select name="category_id" class="form-select" required>
                                    <option value="">اختر القسم...</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">نوع الإعلان</label>
                                <select name="listing_type" class="form-select">
                                    <option value="sale">للبيع</option>
                                    <option value="rent">للإيجار</option>
                                    <option value="exchange">للبدل</option>
                                    <option value="wanted">مطلوب</option>
                                    <option value="free">مجاني</option>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">السعر (بالجنيه السوداني)</label>
                                <input type="number" step="0.01" name="price" class="form-control" placeholder="0.00">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">الحالة</label>
                                <select name="condition_type" class="form-select">
                                    <option value="used">مستعمل</option>
                                    <option value="new">جديد</option>
                                    <option value="used_excellent">مستعمل بحالة ممتازة</option>
                                    <option value="needs_repair">يحتاج صيانة</option>
                                </select>
                            </div>
                        </div>

                        <!-- الموقع الجغرافي المتدرج -->
                        <div class="card p-3 bg-light border-0 mb-3">
                            <h6 class="fw-bold mb-3"><i class="me-1" data-lucide="map-pin"></i>الموقع الجغرافي</h6>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label small">الولاية *</label>
                                    <select name="state_id" id="state_select" class="form-select" required>
                                        <option value="">اختر الولاية...</option>
                                        <?php foreach ($states as $st): ?>
                                            <option value="<?= $st['id'] ?>"><?= $st['name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small">المدينة *</label>
                                    <select name="city_id" id="city_select" class="form-select" required disabled>
                                        <option value="">اختر المدينة...</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small">الحي</label>
                                    <select name="neighborhood_id" id="neighborhood_select" class="form-select" disabled>
                                        <option value="">اختر الحي...</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small">منطقة أو حي إضافي (كتابة يدوية)</label>
                                    <input type="text" name="custom_location" class="form-control form-control-sm" placeholder="مثال: قريب من الميدان الكبير">
                                </div>
                            </div>
                        </div>

                        <!-- التفاصيل والصور -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">وصف الإعلان</label>
                            <textarea name="description" class="form-control" rows="4" placeholder="اكتب تفاصيل المنتج، المواصفات، وسبب البيع..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">صور الإعلان (حتى 5 صور)</label>
                            <input type="file" name="images[]" class="form-control" multiple accept="image/*">
                        </div>

                        <!-- وسائل التواصل -->
                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">رقم الاتصال *</label>
                                <input type="text" name="phone" class="form-control" placeholder="0912345678" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">رقم الواتساب</label>
                                <input type="text" name="whatsapp" class="form-control" placeholder="0912345678">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-warning w-100 py-2 fw-bold fs-5">نشر الإعلان الآن</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// AJAX الربط الديناميكي للموقع الجغرافي
document.getElementById('state_select').addEventListener('change', function() {
    let stateId = this.value;
    let citySelect = document.getElementById('city_select');
    let neighSelect = document.getElementById('neighborhood_select');
    
    citySelect.innerHTML = '<option value="">اختر المدينة...</option>';
    citySelect.disabled = true;
    neighSelect.innerHTML = '<option value="">اختر الحي...</option>';
    neighSelect.disabled = true;

    if (stateId) {
        fetch('<?= BASE_URL ?>ajax/get_cities.php?state_id=' + stateId)
            .then(res => res.json())
            .then(data => {
                data.forEach(city => {
                    citySelect.innerHTML += `<option value="${city.id}">${city.name}</option>`;
                });
                citySelect.disabled = false;
            });
    }
});

document.getElementById('city_select').addEventListener('change', function() {
    let cityId = this.value;
    let neighSelect = document.getElementById('neighborhood_select');
    
    neighSelect.innerHTML = '<option value="">اختر الحي...</option>';
    neighSelect.disabled = true;

    if (cityId) {
        fetch('<?= BASE_URL ?>ajax/get_neighborhoods.php?city_id=' + cityId)
            .then(res => res.json())
            .then(data => {
                if (data.length > 0) {
                    data.forEach(n => {
                        neighSelect.innerHTML += `<option value="${n.id}">${n.name}</option>`;
                    });
                    neighSelect.disabled = false;
                }
            });
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
