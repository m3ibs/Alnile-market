<?php
$pageTitle = 'إدارة الأقسام والمواقع';
require_once __DIR__ . '/../config/app.php';
if (!isAdmin()) redirect('login.php');
$pdo = Database::getInstance();
$ok = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) { $error = 'انتهت صلاحية الطلب، حدّث الصفحة وحاول مجدداً.'; }
    else {
        $action = $_POST['action'] ?? '';
        try {
            if ($action === 'category_save') {
                $id = (int)($_POST['id'] ?? 0); $name = trim($_POST['name'] ?? ''); $icon = trim($_POST['icon'] ?? 'tag'); $sort = (int)($_POST['sort_order'] ?? 0);
                if ($name === '') throw new Exception('اكتب اسم القسم.');
                $slug = 'cat-' . substr(hash('sha256', mb_strtolower($name, 'UTF-8')), 0, 16);
                if ($id) { $q=$pdo->prepare('UPDATE categories SET name=?, icon=?, sort_order=? WHERE id=?'); $q->execute([$name,$icon,$sort,$id]); }
                else { $q=$pdo->prepare('INSERT INTO categories(name,slug,icon,sort_order) VALUES(?,?,?,?)'); $q->execute([$name,$slug,$icon,$sort]); }
                $ok='تم حفظ القسم بنجاح.';
            } elseif ($action === 'category_delete') {
                $id=(int)($_POST['id']??0); $q=$pdo->prepare('SELECT COUNT(*) FROM listings WHERE category_id=?'); $q->execute([$id]);
                if ($q->fetchColumn()) throw new Exception('لا يمكن حذف قسم مرتبط بإعلانات. يمكنك تعديل اسمه بدلاً من ذلك.');
                $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]); $ok='تم حذف القسم.';
            } elseif ($action === 'state_save') {
                $id=(int)($_POST['id']??0); $name=trim($_POST['name']??''); if($name==='') throw new Exception('اكتب اسم الولاية.');
                if($id){$pdo->prepare('UPDATE states SET name=? WHERE id=?')->execute([$name,$id]);}else{$pdo->prepare('INSERT INTO states(name) VALUES(?)')->execute([$name]);} $ok='تم حفظ الولاية.';
            } elseif ($action === 'state_delete') {
                $id=(int)($_POST['id']??0); $q=$pdo->prepare('SELECT COUNT(*) FROM listings WHERE state_id=?');$q->execute([$id]); if($q->fetchColumn()) throw new Exception('لا يمكن حذف ولاية مرتبطة بإعلانات.');
                $pdo->prepare('DELETE FROM states WHERE id=?')->execute([$id]); $ok='تم حذف الولاية ومدنها التابعة.';
            } elseif ($action === 'city_save') {
                $id=(int)($_POST['id']??0);$state=(int)($_POST['state_id']??0);$name=trim($_POST['name']??''); if(!$state||$name==='') throw new Exception('اختر الولاية واكتب اسم المدينة.');
                if($id){$pdo->prepare('UPDATE cities SET state_id=?,name=? WHERE id=?')->execute([$state,$name,$id]);}else{$pdo->prepare('INSERT INTO cities(state_id,name) VALUES(?,?)')->execute([$state,$name]);} $ok='تم حفظ المدينة وربطها بالولاية.';
            } elseif ($action === 'city_delete') { $id=(int)($_POST['id']??0);$q=$pdo->prepare('SELECT COUNT(*) FROM listings WHERE city_id=?');$q->execute([$id]);if($q->fetchColumn()) throw new Exception('لا يمكن حذف مدينة مرتبطة بإعلانات.');$pdo->prepare('DELETE FROM cities WHERE id=?')->execute([$id]);$ok='تم حذف المدينة.'; }
        } catch (PDOException $e) { $error = 'تعذر الحفظ. قد يكون الاسم مستخدماً مسبقاً أو توجد بيانات مرتبطة.'; }
          catch (Exception $e) { $error=$e->getMessage(); }
    }
}
$categories=$pdo->query('SELECT c.*, (SELECT COUNT(*) FROM listings l WHERE l.category_id=c.id AND l.status<>\'deleted\') listing_count FROM categories c ORDER BY sort_order,name')->fetchAll();
$states=$pdo->query('SELECT s.*, (SELECT COUNT(*) FROM cities ci WHERE ci.state_id=s.id) city_count FROM states s ORDER BY name')->fetchAll();
$cities=$pdo->query('SELECT ci.*,s.name state_name,(SELECT COUNT(*) FROM listings l WHERE l.city_id=ci.id AND l.status<>\'deleted\') listing_count FROM cities ci JOIN states s ON s.id=ci.state_id ORDER BY s.name,ci.name')->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
 <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4"><div><span class="eyebrow">إدارة المنصة</span><h2 class="fw-bold mb-1">الأقسام والولايات والمدن</h2><p class="text-muted mb-0">أضف البيانات هنا لتظهر مباشرة في نماذج الإعلانات والصفحة الرئيسية.</p></div><a class="btn btn-outline-dark" href="index.php">العودة للوحة التحكم</a></div>
 <?php if($ok): ?><div class="alert alert-success"><?=sanitize($ok)?></div><?php endif; ?><?php if($error): ?><div class="alert alert-danger"><?=sanitize($error)?></div><?php endif; ?>
 <div class="row g-4">
  <div class="col-lg-6"><section class="glass-panel p-4 h-100"><h4 class="fw-bold mb-3">الأقسام الرئيسية</h4><form method="post" class="row g-2 mb-4"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="category_save"><div class="col-md-5"><input class="form-control" name="name" placeholder="اسم القسم" required></div><div class="col-md-4"><input class="form-control" name="icon" placeholder="أيقونة Lucide" value="tag"></div><div class="col-md-2"><input class="form-control" type="number" name="sort_order" placeholder="الترتيب" value="0"></div><div class="col-md-1"><button class="btn btn-brand w-100" title="إضافة">+</button></div></form>
   <?php foreach($categories as $c): ?><div class="manage-row"><div><b><?=sanitize($c['name'])?></b><small class="d-block text-muted"><?= (int)$c['listing_count']?> إعلان · <?=sanitize($c['icon'])?></small></div><div class="d-flex gap-2"><button class="btn btn-sm btn-outline-dark" type="button" onclick="editRow('cat',<?= (int)$c['id']?>,<?=htmlspecialchars(json_encode([$c['name'],$c['icon'],$c['sort_order']],JSON_HEX_APOS|JSON_HEX_QUOT),ENT_QUOTES)?>)">تعديل</button><form method="post" onsubmit="return confirm('حذف هذا القسم؟')"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="category_delete"><input type="hidden" name="id" value="<?=$c['id']?>"><button class="btn btn-sm btn-outline-danger">حذف</button></form></div></div><?php endforeach; ?>
  </section></div>
  <div class="col-lg-6"><section class="glass-panel p-4 h-100"><h4 class="fw-bold mb-3">الولايات</h4><form method="post" class="input-group mb-4"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="state_save"><input class="form-control" name="name" placeholder="اسم الولاية الجديدة" required><button class="btn btn-brand">إضافة ولاية</button></form>
   <?php foreach($states as $s): ?><div class="manage-row"><div><b><?=sanitize($s['name'])?></b><small class="d-block text-muted"><?= (int)$s['city_count']?> مدينة</small></div><div class="d-flex gap-2"><button class="btn btn-sm btn-outline-dark" onclick="editRow('state',<?=$s['id']?>,<?=htmlspecialchars(json_encode([$s['name']],JSON_HEX_APOS|JSON_HEX_QUOT),ENT_QUOTES)?>)" type="button">تعديل</button><form method="post" onsubmit="return confirm('حذف الولاية وكل مدنها؟')"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="state_delete"><input type="hidden" name="id" value="<?=$s['id']?>"><button class="btn btn-sm btn-outline-danger">حذف</button></form></div></div><?php endforeach; ?>
  </section></div>
  <div class="col-12"><section class="glass-panel p-4"><h4 class="fw-bold mb-3">المدن وربطها بالولايات</h4><form method="post" class="row g-2 mb-4"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="city_save"><div class="col-md-4"><input class="form-control" name="name" placeholder="اسم المدينة" required></div><div class="col-md-5"><select class="form-select" name="state_id" required><option value="">اختر الولاية</option><?php foreach($states as $s):?><option value="<?=$s['id']?>"><?=sanitize($s['name'])?></option><?php endforeach;?></select></div><div class="col-md-3"><button class="btn btn-brand w-100">إضافة مدينة</button></div></form>
  <div class="table-responsive"><table class="table align-middle"><thead><tr><th>المدينة</th><th>الولاية</th><th>الإعلانات</th><th></th></tr></thead><tbody><?php foreach($cities as $ci):?><tr><td><?=sanitize($ci['name'])?></td><td><?=sanitize($ci['state_name'])?></td><td><?=$ci['listing_count']?></td><td><div class="d-flex gap-2"><button type="button" class="btn btn-sm btn-outline-dark" onclick="editCity(<?=$ci['id']?>,<?=htmlspecialchars(json_encode([$ci['name'],$ci['state_id']],JSON_HEX_APOS|JSON_HEX_QUOT),ENT_QUOTES)?>)">تعديل</button><form method="post" onsubmit="return confirm('حذف المدينة؟')"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="city_delete"><input type="hidden" name="id" value="<?=$ci['id']?>"><button class="btn btn-sm btn-outline-danger">حذف</button></form></div></td></tr><?php endforeach;?></tbody></table></div></section></div>
 </div>
</div>
<div class="modal fade" id="editModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="post"><div class="modal-header"><h5 class="modal-title">تعديل البيانات</h5><button type="button" class="btn-close ms-0" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="id" id="editId"><input type="hidden" name="action" id="editAction"><label class="form-label">الاسم</label><input class="form-control mb-3" name="name" id="editName" required><div id="extraFields"><label class="form-label">الأيقونة</label><input class="form-control mb-3" name="icon" id="editIcon"><label class="form-label">الترتيب</label><input class="form-control" type="number" name="sort_order" id="editSort"></div><div id="stateField" class="d-none"><label class="form-label">الولاية</label><select class="form-select" name="state_id" id="editState"><?php foreach($states as $s):?><option value="<?=$s['id']?>"><?=sanitize($s['name'])?></option><?php endforeach;?></select></div></div><div class="modal-footer"><button class="btn btn-brand">حفظ التغييرات</button></div></form></div></div></div>
<script>
function showEdit(type,id,values){document.getElementById('editId').value=id;document.getElementById('editName').value=values[0]||'';document.getElementById('editAction').value=type+'_save';document.getElementById('extraFields').classList.toggle('d-none',type!=='cat');document.getElementById('stateField').classList.toggle('d-none',type!=='city');if(type==='cat'){document.getElementById('editIcon').value=values[1]||'tag';document.getElementById('editSort').value=values[2]||0;}if(type==='city')document.getElementById('editState').value=values[1];new bootstrap.Modal(document.getElementById('editModal')).show();}
function editRow(type,id,values){showEdit(type,id,values)} function editCity(id,values){showEdit('city',id,values)}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
