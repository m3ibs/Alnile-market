<?php
$pageTitle = "لوحة التحكم - الإحصائيات";
require_once __DIR__ . '/../config/app.php';

if (!isAdmin()) {
    redirect('login.php');
}

$pdo = Database::getInstance();

// الإحصائيات الشاملة
$total_users    = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_listings = $pdo->query("SELECT COUNT(*) FROM listings")->fetchColumn();
$active_listings= $pdo->query("SELECT COUNT(*) FROM listings WHERE status = 'active'")->fetchColumn();
$pending_reports= $pdo->query("SELECT COUNT(*) FROM reports WHERE status = 'pending'")->fetchColumn();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold"><i class="me-2" data-lucide="gauge"></i>لوحة تحكم الإدارة</h3>
        <div class="btn-group">
            <a href="users.php" class="btn btn-outline-primary">إدارة المستخدمين</a>
            <a href="listings.php" class="btn btn-outline-primary">إدارة الإعلانات</a>
            <a href="catalog.php" class="btn btn-outline-primary">الأقسام والمواقع</a>
            <a href="reports.php" class="btn btn-outline-danger">البلاغات (<?= $pending_reports ?>)</a>
        </div>
    </div>

    <!-- بطاقات الإحصائيات -->
    <div class="row g-3 mb-5">
        <div class="col-md-3">
            <div class="card admin-stat-card accent p-3 rounded-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">إجمالي المستخدمين</h6>
                        <h2 class="fw-bold mb-0 mt-2"><?= number_format($total_users) ?></h2>
                    </div>
                    <i class="display-4 opacity-50" data-lucide="users"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card admin-stat-card p-3 rounded-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">إجمالي الإعلانات</h6>
                        <h2 class="fw-bold mb-0 mt-2"><?= number_format($total_listings) ?></h2>
                    </div>
                    <i class="display-4 opacity-50" data-lucide="list"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card admin-stat-card p-3 rounded-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">الإعلانات النشطة</h6>
                        <h2 class="fw-bold mb-0 mt-2"><?= number_format($active_listings) ?></h2>
                    </div>
                    <i class="display-4 opacity-50" data-lucide="circle-check"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card admin-stat-card accent p-3 rounded-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">البلاغات المعلقة</h6>
                        <h2 class="fw-bold mb-0 mt-2"><?= number_format($pending_reports) ?></h2>
                    </div>
                    <i class="display-4 opacity-50" data-lucide="triangle-alert"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
