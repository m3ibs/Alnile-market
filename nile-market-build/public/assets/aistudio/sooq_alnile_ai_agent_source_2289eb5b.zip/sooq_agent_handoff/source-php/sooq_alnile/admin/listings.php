<?php
$pageTitle = "إدارة الإعلانات";
require_once __DIR__ . '/../config/app.php';

if (!isAdmin()) {
    redirect('login.php');
}

$pdo = Database::getInstance();

// إجراءات الآدمن (تغيير حالة / تمييز / حذف)
if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $id     = filter_var($_GET['id'], FILTER_VALIDATE_INT);

    if ($action === 'delete') {
        $pdo->prepare("UPDATE listings SET status = 'deleted' WHERE id = ?")->execute([$id]);
    } elseif ($action === 'toggle_featured') {
        $pdo->prepare("UPDATE listings SET is_featured = IF(is_featured=1, 0, 1) WHERE id = ?")->execute([$id]);
    } elseif ($action === 'activate') {
        $pdo->prepare("UPDATE listings SET status = 'active' WHERE id = ?")->execute([$id]);
    }
    redirect('admin/listings.php');
}

$stmt = $pdo->query("SELECT l.*, u.full_name as seller_name, c.name as category_name 
    FROM listings l 
    JOIN users u ON l.user_id = u.id 
    JOIN categories c ON l.category_id = c.id 
    ORDER BY l.id DESC LIMIT 50");
$listings = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">إدارة جميع الإعلانات</h4>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#ID</th>
                            <th>عنوان الإعلان</th>
                            <th>القسم</th>
                            <th>البائع</th>
                            <th>السعر</th>
                            <th>الحالة</th>
                            <th>مميز</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($listings as $item): ?>
                            <tr>
                                <td><?= $item['id'] ?></td>
                                <td><a href="<?= BASE_URL ?>listing-details.php?id=<?= $item['id'] ?>" target="_blank" class="fw-bold text-decoration-none"><?= $item['title'] ?></a></td>
                                <td><?= $item['category_name'] ?></td>
                                <td><?= $item['seller_name'] ?></td>
                                <td class="text-success fw-bold"><?= number_format($item['price']) ?> SDG</td>
                                <td>
                                    <span class="badge bg-<?= $item['status'] === 'active' ? 'success' : 'secondary' ?>"><?= $item['status'] ?></span>
                                </td>
                                <td>
                                    <a href="listings.php?action=toggle_featured&id=<?= $item['id'] ?>" class="btn btn-sm btn-<?= $item['is_featured'] ? 'warning' : 'outline-secondary' ?>">
                                        <i class="" data-lucide="star"></i>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($item['status'] !== 'active'): ?>
                                        <a href="listings.php?action=activate&id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-success">تنشيط</a>
                                    <?php endif; ?>
                                    <a href="listings.php?action=delete&id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('هل أنت تأكد من نقل الإعلان للمحذوفات؟')">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
