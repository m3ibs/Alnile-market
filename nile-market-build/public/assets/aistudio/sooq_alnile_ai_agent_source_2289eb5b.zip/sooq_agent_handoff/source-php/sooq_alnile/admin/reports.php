<?php
$pageTitle = "إدارة البلاغات";
require_once __DIR__ . '/../config/app.php';

if (!isAdmin()) {
    redirect('login.php');
}

$pdo = Database::getInstance();

if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $id     = filter_var($_GET['id'], FILTER_VALIDATE_INT);

    if ($action === 'dismiss') {
        $pdo->prepare("UPDATE reports SET status = 'dismissed' WHERE id = ?")->execute([$id]);
    }
    redirect('admin/reports.php');
}

$stmt = $pdo->query("SELECT r.*, l.title as listing_title, l.id as listing_id 
    FROM reports r 
    JOIN listings l ON r.listing_id = l.id 
    ORDER BY r.id DESC");
$reports = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">قائمة البلاغات الواردة</h4>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#ID</th>
                            <th>الإعلان المُبلغ عنه</th>
                            <th>سبب البلاغ</th>
                            <th>التفاصيل</th>
                            <th>الحالة</th>
                            <th>تاريخ البلاغ</th>
                            <th>الإجراء</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reports as $rep): ?>
                            <tr>
                                <td><?= $rep['id'] ?></td>
                                <td><a href="<?= BASE_URL ?>listing-details.php?id=<?= $rep['listing_id'] ?>" target="_blank"><?= $rep['listing_title'] ?></a></td>
                                <td><span class="badge bg-danger"><?= $rep['reason'] ?></span></td>
                                <td><?= $rep['details'] ?: 'لا توجد تفاصيل إضافية' ?></td>
                                <td><span class="badge bg-<?= $rep['status'] === 'pending' ? 'warning' : 'secondary' ?>"><?= $rep['status'] ?></span></td>
                                <td><?= $rep['created_at'] ?></td>
                                <td>
                                    <?php if ($rep['status'] === 'pending'): ?>
                                        <a href="reports.php?action=dismiss&id=<?= $rep['id'] ?>" class="btn btn-sm btn-outline-secondary">تجاهل البلاغ</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
