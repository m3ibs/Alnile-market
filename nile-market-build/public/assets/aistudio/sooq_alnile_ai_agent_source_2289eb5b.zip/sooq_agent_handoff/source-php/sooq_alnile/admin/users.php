<?php
$pageTitle = "إدارة المستخدمين";
require_once __DIR__ . '/../config/app.php';

if (!isAdmin()) {
    redirect('login.php');
}

$pdo = Database::getInstance();

// معالجة تغيير حالة المستخدم (تجميد / تنشيط)
if (isset($_GET['action'], $_GET['id'])) {
    $action  = sanitize($_GET['action']);
    $user_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

    if ($action === 'suspend') {
        $pdo->prepare("UPDATE users SET status = 'suspended' WHERE id = ? AND role != 'admin'")->execute([$user_id]);
    } elseif ($action === 'activate') {
        $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?")->execute([$user_id]);
    } elseif ($action === 'make_admin') {
        $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?")->execute([$user_id]);
    }
    redirect('admin/users.php');
}

// جلب قائمة المستخدمين
$stmt = $pdo->query("SELECT u.*, s.name as state_name, 
    (SELECT COUNT(*) FROM listings WHERE user_id = u.id) as total_listings 
    FROM users u 
    LEFT JOIN states s ON u.state_id = s.id 
    ORDER BY u.id DESC");
$users = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold mb-0"><i class="text-primary me-2" data-lucide="users-fill"></i>إدارة الحسابات والمستخدمين</h4>
        <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="me-1" data-lucide="arrow-right"></i> العودة للوحة الإحصائيات</a>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#ID</th>
                            <th>الاسم الكامل</th>
                            <th>رقم الهاتف</th>
                            <th>الولاية</th>
                            <th>عدد الإعلانات</th>
                            <th>الدور</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><?= $u['id'] ?></td>
                                <td class="fw-bold"><?= sanitize($u['full_name']) ?></td>
                                <td><a href="tel:<?= $u['phone'] ?>" class="text-decoration-none"><?= sanitize($u['phone']) ?></a></td>
                                <td><?= $u['state_name'] ?? 'غير محدد' ?></td>
                                <td><span class="badge bg-light text-dark border"><?= $u['total_listings'] ?> إعلان</span></td>
                                <td>
                                    <span class="badge bg-<?= $u['role'] === 'admin' ? 'danger' : 'info' ?>"><?= $u['role'] === 'admin' ? 'مدير' : 'مستخدم' ?></span>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $u['status'] === 'active' ? 'success' : 'secondary' ?>"><?= $u['status'] === 'active' ? 'نشط' : 'محظور' ?></span>
                                </td>
                                <td>
                                    <?php if ($u['role'] !== 'admin'): ?>
                                        <?php if ($u['status'] === 'active'): ?>
                                            <a href="users.php?action=suspend&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('هل تريد حظر هذا الحساب؟')">حظر الحساب</a>
                                        <?php else: ?>
                                            <a href="users.php?action=activate&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-success">إلغاء الحظر</a>
                                        <?php endif; ?>
                                        <a href="users.php?action=make_admin&id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-warning" onclick="return confirm('هل تريد منح هذا المستخدم صلاحية مدير؟')">ترقية لـ أدمن</a>
                                    <?php else: ?>
                                        <span class="text-muted small">حساب أدمن رئيسي</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
