<?php
// ajax/get_cities.php
require_once __DIR__ . '/../config/app.php';

header('Content-Type: application/json; charset=utf-8');

$state_id = filter_var($_GET['state_id'] ?? null, FILTER_VALIDATE_INT);

if (!$state_id) {
    echo json_encode([]);
    exit;
}

$pdo = Database::getInstance();
$stmt = $pdo->prepare("SELECT id, name FROM cities WHERE state_id = ? ORDER BY name ASC");
$stmt->execute([$state_id]);
$cities = $stmt->fetchAll();

echo json_encode($cities);
