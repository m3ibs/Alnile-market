<?php
// ajax/get_neighborhoods.php
require_once __DIR__ . '/../config/app.php';

header('Content-Type: application/json; charset=utf-8');

$city_id = filter_var($_GET['city_id'] ?? null, FILTER_VALIDATE_INT);

if (!$city_id) {
    echo json_encode([]);
    exit;
}

$pdo = Database::getInstance();
$stmt = $pdo->prepare("SELECT id, name FROM neighborhoods WHERE city_id = ? ORDER BY name ASC");
$stmt->execute([$city_id]);
$neighborhoods = $stmt->fetchAll();

echo json_encode($neighborhoods);
