<?php
// ajax/report_listing.php
require_once __DIR__ . '/../config/app.php';

header('Content-Type: application/json; charset=utf-8');

$listing_id = filter_var($_POST['listing_id'] ?? null, FILTER_VALIDATE_INT);
$reason     = sanitize($_POST['reason'] ?? '');
$details    = sanitize($_POST['details'] ?? '');
$user_id    = $_SESSION['user_id'] ?? null;

$allowed_reasons = ['fraud', 'fake', 'prohibited', 'wrong_price', 'duplicate', 'other'];

if (!$listing_id || !in_array($reason, $allowed_reasons)) {
    echo json_encode(['status' => 'error', 'message' => 'بيانات البلاغ غير صالحة']);
    exit;
}

$pdo = Database::getInstance();
$stmt = $pdo->prepare("INSERT INTO reports (user_id, listing_id, reason, details) VALUES (?, ?, ?, ?)");

if ($stmt->execute([$user_id, $listing_id, $reason, $details])) {
    echo json_encode(['status' => 'success', 'message' => 'تم استلام بلاغك وسيقوم الفريق بمراجعته.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'حدث خطأ أثناء إرسال البلاغ']);
}
