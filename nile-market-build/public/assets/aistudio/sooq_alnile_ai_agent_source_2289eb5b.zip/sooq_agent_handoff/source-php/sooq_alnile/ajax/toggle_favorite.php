<?php
// ajax/toggle_favorite.php
require_once __DIR__ . '/../config/app.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    echo json_encode(['status' => 'error', 'message' => 'يرجى تسجيل الدخول أولاً']);
    exit;
}

$listing_id = filter_var($_POST['listing_id'] ?? null, FILTER_VALIDATE_INT);
$user_id    = $_SESSION['user_id'];

if (!$listing_id) {
    echo json_encode(['status' => 'error', 'message' => 'معرف الإعلان غير صالح']);
    exit;
}

$pdo = Database::getInstance();

// التحقق مما إذا كان الإعلان في المفضلة سابقاً
$stmt = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND listing_id = ?");
$stmt->execute([$user_id, $listing_id]);
$favorite = $stmt->fetch();

if ($favorite) {
    // إزالة من المفضلة
    $delete = $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND listing_id = ?");
    $delete->execute([$user_id, $listing_id]);
    echo json_encode(['status' => 'removed', 'message' => 'تمت إزالة الإعلان من المفضلة']);
} else {
    // إضافة للمفضلة
    $insert = $pdo->prepare("INSERT INTO favorites (user_id, listing_id) VALUES (?, ?)");
    $insert->execute([$user_id, $listing_id]);
    echo json_encode(['status' => 'added', 'message' => 'تم إضافة الإعلان للمفضلة']);
}
