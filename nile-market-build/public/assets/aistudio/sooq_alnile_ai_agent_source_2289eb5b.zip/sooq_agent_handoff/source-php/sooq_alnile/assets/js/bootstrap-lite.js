/* Small local compatibility layer for the Bootstrap interactions used by this site. */
(function(){
  const qs=(s,r=document)=>r.querySelector(s);
  class Modal{
    constructor(el){this.el=el;}
    show(){this.el.classList.add('show');this.el.style.display='block';document.body.classList.add('modal-open');}
    hide(){this.el.classList.remove('show');this.el.style.display='none';document.body.classList.remove('modal-open');}
    static getInstance(el){return el?._nileModal||null;}
    static getOrCreateInstance(el){return el._nileModal||(el._nileModal=new Modal(el));}
  }
  document.addEventListener('click',e=>{
    const toggle=e.target.closest('[data-bs-toggle="collapse"]');
    if(toggle){const el=qs(toggle.getAttribute('data-bs-target'));if(el){el.classList.toggle('show');toggle.setAttribute('aria-expanded',el.classList.contains('show')?'true':'false');} }
    const modalTrigger=e.target.closest('[data-bs-toggle="modal"]');
    if(modalTrigger){const el=qs(modalTrigger.getAttribute('data-bs-target'));if(el)Modal.getOrCreateInstance(el).show();}
    const dismiss=e.target.closest('[data-bs-dismiss="modal"]');
    if(dismiss){const el=e.target.closest('.modal');if(el)Modal.getOrCreateInstance(el).hide();}
    const slide=e.target.closest('[data-bs-slide]');
    if(slide){const target=qs(slide.getAttribute('data-bs-target'));if(target){const items=[...target.querySelectorAll('.carousel-item')];if(items.length>1){let i=items.findIndex(x=>x.classList.contains('active'));i=(i+(slide.dataset.bsSlide==='next'?1:-1)+items.length)%items.length;items.forEach((x,n)=>x.classList.toggle('active',n===i));}}}
    if(e.target.classList.contains('modal'))Modal.getOrCreateInstance(e.target).hide();
  });
  window.bootstrap={Modal};
})();
