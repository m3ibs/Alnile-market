// assets/js/main.js

// حفظ وإزالة الإعلان من المفضلة
function toggleFavorite(listingId, btnElement) {
    let formData = new FormData();
    formData.append('listing_id', listingId);

    fetch((window.NILE_BASE_URL || './') + 'ajax/toggle_favorite.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'added') {
            btnElement.classList.remove('btn-outline-danger');
            btnElement.classList.add('btn-danger');
            btnElement.innerHTML = '♡ مفضل';
    
        } else if (data.status === 'removed') {
            btnElement.classList.remove('btn-danger');
            btnElement.classList.add('btn-outline-danger');
            btnElement.innerHTML = '♡ حفظ للإعلانات المفضلة';
    
        } else {
            alert(data.message);
        }
    })
    .catch(err => console.error('Error:', err));
}

// إرسال البلاغات
function submitReport(listingId, reason, details) {
    let formData = new FormData();
    formData.append('listing_id', listingId);
    formData.append('reason', reason);
    formData.append('details', details);

    fetch((window.NILE_BASE_URL || './') + 'ajax/report_listing.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if (data.status === 'success') {
            let modalElement = document.getElementById('reportModal');
            if (modalElement) {
                let modal = bootstrap.Modal.getInstance(modalElement);
                if (modal) modal.hide();
            }
        }
    })
    .catch(err => console.error('Error:', err));
}


// Tiny local icon fallback: avoids a blocking third-party icon library.
document.addEventListener('DOMContentLoaded', function(){
  const icons={house:'⌂', 'layout-dashboard':'▦', 'plus-circle':'+', 'user-round':'●', 'log-out':'↪', search:'⌕', 'grid-3x3':'▦', 'clock-history':'◷', info:'i', 'map-pin':'⌖', eye:'◉', clock:'◷', heart:'♡', image:'▧', flag:'⚑', 'phone-call':'☎', 'circle-user':'●', tag:'◆', 'car-front':'▰', house:'⌂', 'key-round':'⚿', 'shopping-bag':'▣', smartphone:'▯', laptop:'▱', wrench:'⚒', 'menu':'☰'};
  document.querySelectorAll('[data-lucide]').forEach(el=>{const key=el.getAttribute('data-lucide');el.textContent=icons[key]||'•';el.classList.add('nile-icon-fallback');el.setAttribute('aria-hidden','true');});
});

// Hide immediately after the DOM is ready; never wait for slow third-party assets.
(function(){
  const hide=()=>{
    const loader=document.getElementById('pageLoader');
    if(!loader)return;
    loader.classList.add('is-hidden');
    window.setTimeout(()=>loader.remove(),220);
  };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',hide,{once:true});
  else hide();
  window.setTimeout(hide,1800);
})();
