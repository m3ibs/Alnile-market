<?php
// config/app.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('SITE_NAME', 'سوق النيل');
define('SITE_SLOGAN', 'كل السودان في سوق واحد');
// Resolve the installation URL automatically (works in localhost and production).
$scriptDir = str_replace('\\\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
$scriptDir = preg_replace('~/(admin|ajax)$~', '', $scriptDir);
$basePath = rtrim($scriptDir, '/') . '/';
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
define('BASE_URL', ($isHttps ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $basePath);
define('UPLOAD_PATH', __DIR__ . '/../uploads/');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/functions.php';
