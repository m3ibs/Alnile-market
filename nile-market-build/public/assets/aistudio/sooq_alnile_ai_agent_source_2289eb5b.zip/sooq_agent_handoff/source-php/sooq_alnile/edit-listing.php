<?php
$pageTitle = "تعديل الإعلان";
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$pdo = Database::getInstance();
$listing_id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$user_id    = $_SESSION['user_id'];

// التحقق من ملكية الإعلان
$stmt = $pdo->prepare("SELECT * FROM listings WHERE id = ? AND user_id = ? AND status != 'deleted'");
$stmt->execute([$listing_id, $user_id]);
$listing = $stmt->fetch();

if (!$listing) {
    redirect('profile.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "رمز الحماية غير صالح.";
    }

    $title          = sanitize($_POST['title'] ?? '');
    $price          = filter_var($_POST['price'] ?? 0, FILTER_VALIDATE_FLOAT);
    $description    = sanitize($_POST['description'] ?? '');
    $phone          = sanitize($_POST['phone'] ?? '');
    $whatsapp       = sanitize($_POST['whatsapp'] ?? '');
    $condition_type = sanitize($_POST['condition_type'] ?? 'used');

    if (empty($title)) $errors[] = "يرجى إدخال عنوان الإعلان.";
    if (empty($phone)) $errors[] = "يرجى إدخال رقم الهاتف.";

    if (empty($errors)) {
        $update_stmt = $pdo->prepare("UPDATE listings SET title = ?, price = ?, description = ?, phone = ?, whatsapp = ?, condition_type = ? WHERE id = ? AND user_id = ?");
        if ($update_stmt->execute([$title, $price, $description, $phone, $whatsapp, $condition_type, $listing_id, $user_id])) {
            redirect('profile.php');
        } else {
            $errors[] = "حدث خطأ أثناء حفظ التحديثات.";
        }
    }
}
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card shadow-sm border-0 rounded-3 p-4">
                <h4 class="fw-bold mb-4"><i class="text-primary me-2" data-lucide="pencil-square"></i>تعديل الإعلان</h4>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger py-2 mb-3">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

                    <div class="mb-3">
                        <label class="form-label fw-bold">عنوان الإعلان</label>
                        <input type="text" name="title" class="form-control" value="<?= sanitize($listing['title']) ?>" required>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">السعر (SDG)</label>
                            <input type="number" step="0.01" name="price" class="form-control" value="<?= $listing['price'] ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">الحالة</label>
                            <select name="condition_type" class="form-select">
                                <option value="used" <?= $listing['condition_type'] === 'used' ? 'selected' : '' ?>>مستعمل</option>
                                <option value="new" <?= $listing['condition_type'] === 'new' ? 'selected' : '' ?>>جديد</option>
                                <option value="used_excellent" <?= $listing['condition_type'] === 'used_excellent' ? 'selected' : '' ?>>مستعمل بحالة ممتازة</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">وصف الإعلان</label>
                        <textarea name="description" class="form-control" rows="4"><?= sanitize($listing['description']) ?></textarea>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">رقم الاتصال</label>
                            <input type="text" name="phone" class="form-control" value="<?= sanitize($listing['phone']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">رقم الواتساب</label>
                            <input type="text" name="whatsapp" class="form-control" value="<?= sanitize($listing['whatsapp']) ?>">
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100 fw-bold">حفظ التغييرات</button>
                        <a href="profile.php" class="btn btn-outline-secondary w-100">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
