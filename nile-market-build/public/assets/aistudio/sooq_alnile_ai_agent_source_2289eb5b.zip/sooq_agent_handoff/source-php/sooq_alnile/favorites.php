<?php
$pageTitle = "الإعلانات المفضلة";
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$pdo = Database::getInstance();
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT l.*, c.name as category_name, s.name as state_name, ci.name as city_name,
        (SELECT image_path FROM listing_images WHERE listing_id = l.id ORDER BY is_primary DESC LIMIT 1) as primary_image
        FROM favorites f
        JOIN listings l ON f.listing_id = l.id
        JOIN categories c ON l.category_id = c.id
        JOIN states s ON l.state_id = s.id
        JOIN cities ci ON l.city_id = ci.id
        WHERE f.user_id = ? AND l.status = 'active'
        ORDER BY f.id DESC");
$stmt->execute([$user_id]);
$favorites = $stmt->fetchAll();
?>

<div class="container py-4">
    <h4 class="fw-bold mb-4"><i class="text-danger me-2" data-lucide="heart"></i>الإعلانات المفضلة</h4>

    <?php if (empty($favorites)): ?>
        <div class="alert alert-info text-center py-4">
            <i class="display-5 d-block mb-2" data-lucide="heart"></i>
            لا توجد إعلانات محفوظة في قائمة المفضلة لديك حالياً.
        </div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach ($favorites as $item): ?>
                <div class="col">
                    <div class="card h-100 card-listing">
                        <img src="<?= $item['primary_image'] ? BASE_URL . 'uploads/listings/' . $item['primary_image'] : 'https://via.placeholder.com/300x200?text=بدون+صورة' ?>" class="card-img-top" style="height: 180px; object-fit: cover;" alt="<?= $item['title'] ?>">
                        <div class="card-body">
                            <span class="badge bg-light text-primary mb-2"><?= $item['category_name'] ?></span>
                            <h6 class="card-title text-truncate fw-bold mb-1">
                                <a href="listing-details.php?id=<?= $item['id'] ?>" class="text-decoration-none text-dark"><?= $item['title'] ?></a>
                            </h6>
                            <p class="text-success fw-bold mb-2"><?= formatPrice($item['price']) ?></p>
                            <div class="d-flex justify-content-between text-muted small">
                                <span><i class="me-1" data-lucide="map-pin"></i><?= $item['state_name'] ?></span>
                                <span><?= timeAgo($item['created_at']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
