<?php
// includes/functions.php

function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function formatPrice($price) {
    return number_format($price, 0, '.', ',') . ' جنيه سوداني';
}

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $difference = time() - $timestamp;

    if ($difference < 60) return 'منذ لحظات';
    if ($difference < 3600) return 'منذ ' . floor($difference / 60) . ' دقيقة';
    if ($difference < 86400) return 'منذ ' . floor($difference / 3600) . ' ساعة';
    if ($difference < 2592000) return 'منذ ' . floor($difference / 86400) . ' يوم';
    return date('Y-m-d', $timestamp);
}
