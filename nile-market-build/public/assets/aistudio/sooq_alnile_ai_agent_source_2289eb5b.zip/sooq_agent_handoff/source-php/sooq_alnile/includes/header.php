<?php require_once __DIR__ . '/../config/app.php'; ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#101010">
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>assets/img/logo.png">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') . " - " . SITE_NAME : SITE_NAME . " | " . SITE_SLOGAN ?></title>
    <meta name="color-scheme" content="light">
    <link rel="manifest" href="<?= BASE_URL ?>manifest.webmanifest">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="page-loader" id="pageLoader" aria-label="جاري تحميل سوق النيل"><img src="<?= BASE_URL ?>assets/img/logo.png" alt="سوق النيل"><span class="loader-line"></span></div><script>setTimeout(function(){var l=document.getElementById("pageLoader");if(l){l.classList.add("is-hidden");setTimeout(function(){l.remove()},220)}},750);</script>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top site-navbar">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= BASE_URL ?>">
            <span class="nav-logo-wrap"><img src="<?= BASE_URL ?>assets/img/logo.png" class="nav-logo" alt="سوق النيل"></span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="فتح القائمة">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>"><i data-lucide="house"></i> الرئيسية</a></li>
                <?php if (isLoggedIn() && isAdmin()): ?>
                    <li class="nav-item"><a class="nav-link admin-nav-link" href="<?= BASE_URL ?>admin/index.php"><i data-lucide="layout-dashboard"></i> لوحة الإدارة</a></li>
                <?php endif; ?>
            </ul>
            <div class="d-flex flex-wrap align-items-center gap-2 py-2 py-lg-0">
                <?php if (isLoggedIn()): ?>
                    <a href="<?= BASE_URL ?>add-listing.php" class="btn btn-brand"><i data-lucide="plus-circle"></i> أضف إعلانك</a>
                    <a href="<?= BASE_URL ?>profile.php" class="btn btn-outline-light"><i data-lucide="user-round"></i> حسابي</a>
                    <a href="<?= BASE_URL ?>logout.php" class="btn btn-outline-light" aria-label="تسجيل الخروج"><i data-lucide="log-out"></i></a>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>login.php" class="btn btn-outline-light">تسجيل الدخول</a>
                    <a href="<?= BASE_URL ?>register.php" class="btn btn-brand">حساب جديد</a>
                    <a href="<?= BASE_URL ?>add-listing.php" class="btn btn-outline-light"><i data-lucide="plus-circle"></i> أضف إعلانك</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<script>window.NILE_BASE_URL = <?= json_encode(BASE_URL) ?>;</script>
