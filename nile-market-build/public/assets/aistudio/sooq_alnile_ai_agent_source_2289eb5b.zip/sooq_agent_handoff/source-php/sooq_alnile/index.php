<?php
$pageTitle = "الرئيسية";
require_once __DIR__ . '/includes/header.php';

$pdo = Database::getInstance();

// جلب الأقسام الرئيسية
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order ASC")->fetchAll();
$categoryIconMap = [
    'bi-car-front' => 'car-front', 'bi-house-door' => 'house',
    'bi-key' => 'key-round', 'bi-bag-heart' => 'shopping-bag',
    'bi-person' => 'user-round', 'bi-phone' => 'smartphone',
    'bi-laptop' => 'laptop', 'bi-tools' => 'wrench'
];

// جلب الولايات للفلترة
$states = $pdo->query("SELECT * FROM states ORDER BY name ASC")->fetchAll();

// معالجة الفلاتر والبحث
$search_query = sanitize($_GET['q'] ?? '');
$state_filter = filter_var($_GET['state_id'] ?? null, FILTER_VALIDATE_INT);
$cat_filter   = filter_var($_GET['category_id'] ?? null, FILTER_VALIDATE_INT);

// بناء استعلام البحث
$sql = "SELECT l.*, c.name as category_name, s.name as state_name, ci.name as city_name,
        (SELECT image_path FROM listing_images WHERE listing_id = l.id ORDER BY is_primary DESC, id ASC LIMIT 1) as primary_image,
        u.full_name AS seller_name, u.avatar AS seller_avatar
        FROM listings l
        JOIN users u ON u.id = l.user_id
        JOIN categories c ON l.category_id = c.id
        JOIN states s ON l.state_id = s.id
        JOIN cities ci ON l.city_id = ci.id
        WHERE l.status = 'active'";

$params = [];

if (!empty($search_query)) {
    $sql .= " AND (l.title LIKE ? OR l.description LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
}

if ($state_filter) {
    $sql .= " AND l.state_id = ?";
    $params[] = $state_filter;
}

if ($cat_filter) {
    $sql .= " AND l.category_id = ?";
    $params[] = $cat_filter;
}

$sql .= " ORDER BY l.id DESC LIMIT 12";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$listings = $stmt->fetchAll();
?>

<!-- Hero Search Bar -->
<div class="hero-search mb-4 text-center">
    <div class="container">
        <h2 class="fw-bold mb-3">بتفتش عن شنو؟</h2>
        <form action="" method="GET" class="row g-2 justify-content-center">
            <div class="col-md-5">
                <input type="text" name="q" class="form-control form-control-lg" placeholder="سيارة، شقة للإيجار، آيفون، ثلاجة..." value="<?= $search_query ?>">
            </div>
            <div class="col-md-3">
                <select name="state_id" class="form-select form-select-lg">
                    <option value="">جميع الولايات</option>
                    <?php foreach ($states as $st): ?>
                        <option value="<?= $st['id'] ?>" <?= $state_filter == $st['id'] ? 'selected' : '' ?>><?= $st['name'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-warning btn-lg w-100 fw-bold"><i class="me-1" data-lucide="search"></i> بحث</button>
            </div>
        </form>
    </div>
</div>

<div class="container">
    <!-- Categories Grid -->
    <h5 class="fw-bold mb-3"><i class="me-2 text-primary" data-lucide="grid-3x3"></i>الأقسام الرئيسية</h5>
    <div class="row row-cols-2 row-cols-md-4 row-cols-lg-6 g-3 mb-5">
        <?php foreach ($categories as $cat): ?>
            <div class="col text-center">
                <a href="index.php?category_id=<?= $cat['id'] ?>" class="card h-100 card-listing text-decoration-none text-dark p-3">
                    <i class="display-6 text-primary mb-2" data-lucide="<?= htmlspecialchars($categoryIconMap[$cat['icon']] ?? 'tag', ENT_QUOTES, 'UTF-8') ?>"></i>
                    <span class="fw-bold small d-block"><?= $cat['name'] ?></span>
                </a>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Latest Listings -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0"><i class="me-2 text-primary" data-lucide="clock-history"></i>أحدث الإعلانات</h5>
    </div>

    <?php if (empty($listings)): ?>
        <div class="alert alert-info text-center py-4">
            <i class="display-5 d-block mb-2" data-lucide="info"></i>
            لا توجد إعلانات مطابقة لخيارات البحث حالياً.
        </div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach ($listings as $item): ?>
                <div class="col">
                    <a class="card h-100 card-listing listing-card-link" href="listing-details.php?id=<?= (int)$item['id'] ?>" aria-label="عرض تفاصيل <?= sanitize($item['title']) ?>">
                        <img loading="lazy" decoding="async" width="640" height="360" src="<?= $item['primary_image'] ? BASE_URL . 'uploads/listings/' . rawurlencode($item['primary_image']) : BASE_URL . 'assets/img/no-image.svg' ?>" class="card-img-top" style="height: 180px; object-fit: cover;" alt="<?= sanitize($item['title']) ?>">
                        <div class="card-body">
                            <span class="badge bg-light text-primary mb-2"><?= $item['category_name'] ?></span>
                            <h6 class="card-title text-truncate fw-bold mb-1">
                                <?= sanitize($item['title']) ?>
                            </h6>
                            <p class="listing-price fw-bold mb-2"><?= formatPrice($item['price']) ?></p>
                            <div class="listing-seller"><img loading="lazy" src="<?= $item['seller_avatar'] && $item['seller_avatar'] !== 'default_avatar.png' ? BASE_URL . 'uploads/avatars/' . rawurlencode($item['seller_avatar']) : BASE_URL . 'assets/img/avatar-placeholder.svg' ?>" alt=""><span><?= sanitize($item['seller_name']) ?></span></div>
                            <div class="d-flex justify-content-between text-muted small">
                                <span><i class="me-1" data-lucide="map-pin"></i><?= $item['state_name'] ?> - <?= $item['city_name'] ?></span>
                                <span><?= timeAgo($item['created_at']) ?></span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
