<?php
$pageTitle = "تفاصيل الإعلان";
require_once __DIR__ . '/includes/header.php';

$pdo = Database::getInstance();
$id  = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);

if (!$id) {
    redirect('');
}

// زيادة التفاعلات والمشاهدات
$pdo->prepare("UPDATE listings SET views_count = views_count + 1 WHERE id = ?")->execute([$id]);

// جلب تفاصيل الإعلان والمالك
$stmt = $pdo->prepare("SELECT l.*, c.name as category_name, s.name as state_name, ci.name as city_name, n.name as neighborhood_name, u.full_name as seller_name, u.avatar as seller_avatar
    FROM listings l
    JOIN categories c ON l.category_id = c.id
    JOIN states s ON l.state_id = s.id
    JOIN cities ci ON l.city_id = ci.id
    LEFT JOIN neighborhoods n ON l.neighborhood_id = n.id
    JOIN users u ON l.user_id = u.id
    WHERE l.id = ? AND l.status = 'active'");
$stmt->execute([$id]);
$item = $stmt->fetch();

$whatsappNumber = preg_replace('/\D+/', '', (string)($item['whatsapp'] ?? ''));
if ($whatsappNumber !== '') {
    if (strpos($whatsappNumber, '249') !== 0) {
        $whatsappNumber = '249' . ltrim($whatsappNumber, '0');
    }
}

if (!$item) {
    echo "<div class='container py-5 text-center'><h4>الإعلان غير موجود أو تم إيقافه.</h4><a href='index.php' class='btn btn-primary mt-3'>العودة للرئيسية</a></div>";
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// جلب الصور
$img_stmt = $pdo->prepare("SELECT image_path FROM listing_images WHERE listing_id = ? ORDER BY is_primary DESC");
$img_stmt->execute([$id]);
$images = $img_stmt->fetchAll();

// التحقق هل الإعلان في مفضلة المستخدم الحالي
$is_fav = false;
if (isLoggedIn()) {
    $fav_check = $pdo->prepare("SELECT id FROM favorites WHERE user_id = ? AND listing_id = ?");
    $fav_check->execute([$_SESSION['user_id'], $id]);
    $is_fav = (bool)$fav_check->fetch();
}
?>

<div class="container py-4">
    <div class="row g-4">
        <!-- المعرض والتفاصيل -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-3 mb-4">
                <div class="card-body p-3">
                    <?php if (!empty($images)): ?>
                        <div id="listingCarousel" class="carousel slide bg-light rounded" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php foreach ($images as $index => $img): ?>
                                    <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                                        <img src="<?= BASE_URL . 'uploads/listings/' . $img['image_path'] ?>" class="d-block w-100" style="max-height: 450px; object-fit: contain;" alt="<?= sanitize($item['title']) ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php if (count($images) > 1): ?>
                                <button class="carousel-control-prev" type="button" data-bs-target="#listingCarousel" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon bg-dark rounded-circle"></span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#listingCarousel" data-bs-slide="next">
                                    <span class="carousel-control-next-icon bg-dark rounded-circle"></span>
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="bg-light text-center py-5 rounded">
                            <i class="display-1 text-muted" data-lucide="image"></i>
                            <p class="text-muted mb-0">لا توجد صور متوفرة للإعلان</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-3 p-4">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="badge bg-primary fs-6"><?= $item['category_name'] ?></span>
                    <button class="btn btn-sm <?= $is_fav ? 'btn-danger' : 'btn-outline-danger' ?>" onclick="toggleFavorite(<?= $item['id'] ?>, this)">
                        <i class="me-1" data-lucide="heart"></i> <?= $is_fav ? 'مفضل' : 'حفظ للإعلانات المفضلة' ?>
                    </button>
                </div>

                <h3 class="fw-bold mb-2"><?= sanitize($item['title']) ?></h3>
                <h4 class="text-success fw-bold mb-4"><?= formatPrice($item['price']) ?></h4>

                <hr>

                <h5 class="fw-bold mb-3">تفاصيل الإعلان</h5>
                <p class="text-secondary style-description" style="white-space: pre-line; line-height: 1.8;"><?= sanitize($item['description']) ?></p>

                <hr>

                <div class="row g-2 text-muted small">
                    <div class="col-md-6"><i class="text-primary me-1" data-lucide="map-pin"></i><?= $item['state_name'] ?> - <?= $item['city_name'] ?> <?= $item['neighborhood_name'] ? "({$item['neighborhood_name']})" : '' ?></div>
                    <div class="col-md-6"><i class="text-primary me-1" data-lucide="eye"></i>المشاهدات: <?= $item['views_count'] ?></div>
                    <div class="col-md-6"><i class="text-primary me-1" data-lucide="clock"></i>تاريخ النشر: <?= timeAgo($item['created_at']) ?></div>
                    <div class="col-md-6"><i class="text-primary me-1" data-lucide="info"></i>الحالة: <?= $item['condition_type'] === 'new' ? 'جديد' : 'مستعمل' ?></div>
                </div>
            </div>
        </div>

        <!-- كارت التواصل والتفاعل -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-3 p-4 sticky-top" style="top: 80px;">
                <h6 class="text-muted mb-2">التاجر / المعلن</h6>
                <div class="seller-profile-chip mb-3"><img src="<?= $item['seller_avatar'] && $item['seller_avatar'] !== 'default_avatar.png' ? BASE_URL . 'uploads/avatars/' . rawurlencode($item['seller_avatar']) : BASE_URL . 'assets/img/avatar-placeholder.svg' ?>" alt="صورة <?= sanitize($item['seller_name']) ?>"><div><strong><?= sanitize($item['seller_name']) ?></strong><small>ناشر الإعلان</small></div></div>

                <div class="d-grid gap-2 mb-4">
                    <a href="tel:<?= rawurlencode(preg_replace('/[^0-9+]/', '', $item['phone'])) ?>" class="btn btn-primary btn-lg fw-bold"><i class="me-2" data-lucide="phone-call"></i> اتصال مباشر</a>
                    <?php if ($whatsappNumber !== ''): ?>
                        <a href="https://wa.me/<?= $whatsappNumber ?>?text=<?= urlencode('مرحباً، أستفسر عن إعلانك في سوق النيل: ' . $item['title']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp btn-lg fw-bold"><span class="whatsapp-mark me-2" aria-hidden="true">WA</span> مراسلة واتساب</a>
                    <?php endif; ?>
                </div>

                <hr>

                <!-- مشاركة الإعلان والتبليغ -->
                <div class="d-flex justify-content-between align-items-center">
                    <span class="fw-bold small">مشاركة الإعلان:</span>
                    <div class="d-flex gap-2">
                        <a href="https://wa.me/?text=<?= urlencode($item['title'] . ' ' . BASE_URL . 'listing-details.php?id=' . $item['id']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-success"><span class="whatsapp-mark" aria-hidden="true">WA</span></a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(BASE_URL . 'listing-details.php?id=' . $item['id']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary"><span class="facebook-mark" aria-hidden="true">f</span></a>
                    </div>
                </div>

                <button type="button" class="btn btn-link text-danger btn-sm text-decoration-none mt-3 p-0" data-bs-toggle="modal" data-bs-target="#reportModal">
                    <i class="me-1" data-lucide="flag"></i> الإبلاغ عن هذا الإعلان
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Modal التبليغ عن الإعلان -->
<div class="modal fade" id="reportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">الإبلاغ عن الإعلان</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="reportForm">
                    <div class="mb-3">
                        <label class="form-label fw-bold">سبب البلاغ</label>
                        <select id="reportReason" class="form-select" required>
                            <option value="fraud">احتيال أو قرار وهمي</option>
                            <option value="fake">إعلان مكرر / غير حقيقي</option>
                            <option value="prohibited">منتج ممنوع</option>
                            <option value="wrong_price">سعر غير صحيح</option>
                            <option value="other">سبب آخر</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">تفاصيل إضافية</label>
                        <textarea id="reportDetails" class="form-control" rows="3" placeholder="اكتب التفاصيل التي تساند بلاغك..."></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-danger" onclick="submitReport(<?= $item['id'] ?>, document.getElementById('reportReason').value, document.getElementById('reportDetails').value)">إرسال البلاغ</button>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
