<?php
$pageTitle = "تسجيل الدخول";
require_once __DIR__ . '/includes/header.php';

if (isLoggedIn()) {
    redirect(isAdmin() ? 'admin/index.php' : '');
}

$pdo = Database::getInstance();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "رمز الحماية غير صالح، يرجى إعادة المحاولة.";
    }

    $phone    = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($phone) || empty($password)) {
        $errors[] = "يرجى كتابة رقم الهاتف وكلمة المرور.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE phone = ? AND status = 'active'");
        $stmt->execute([$phone]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_role'] = $user['role'];
            redirect($user['role'] === 'admin' ? 'admin/index.php' : '');
        } else {
            $errors[] = "بيانات الدخول غير صحيحة أو الحساب معطل.";
        }
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-body p-4">
                    <div class="text-center mb-4"><img src="<?= BASE_URL ?>assets/img/logo.png" class="auth-logo" alt="شعار سوق النيل"><h4 class="card-title mt-3 mb-1 fw-bold">مرحباً بك في سوق النيل</h4><p class="text-muted small mb-0">سجّل دخولك وتسوّق بكل سهولة</p></div>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger py-2">
                            <ul class="mb-0 ps-3">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف</label>
                            <input type="text" name="phone" class="form-control" placeholder="0912345678" required value="<?= htmlspecialchars($phone ?? '', ENT_QUOTES, 'UTF-8') ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">دخول</button>
                    </form>

                    <div class="text-center mt-3">
                        <small class="text-muted">ليس لديك حساب؟ <a href="register.php">أنشئ حساباً جديداً</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
