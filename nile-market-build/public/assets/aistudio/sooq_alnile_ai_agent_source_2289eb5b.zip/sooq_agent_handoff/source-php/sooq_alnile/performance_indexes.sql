-- تشغيل اختياري مرة واحدة على قاعدة بيانات موجودة لتسريع الإعلانات والصور.
-- إذا ظهرت رسالة بأن الفهرس موجود بالفعل، تجاهل ذلك السطر.
ALTER TABLE listings ADD INDEX idx_listings_status_id (status, id);
ALTER TABLE listings ADD INDEX idx_listings_category_status (category_id, status);
ALTER TABLE listings ADD INDEX idx_listings_state_status (state_id, status);
ALTER TABLE listing_images ADD INDEX idx_listing_images_primary (listing_id, is_primary, id);
