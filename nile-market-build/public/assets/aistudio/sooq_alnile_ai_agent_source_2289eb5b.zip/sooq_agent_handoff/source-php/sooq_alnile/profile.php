<?php
$pageTitle = "حسابي وإعلاناتي";
require_once __DIR__ . '/includes/header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$pdo = Database::getInstance();
$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';
// تحديث الصورة الشخصية بصورة آمنة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_avatar') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) { $error_msg = 'رمز الحماية غير صالح.'; }
    elseif (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) { $error_msg = 'اختر صورة صالحة لرفعها.'; }
    else {
        $file = $_FILES['avatar'];
        if ($file['size'] > 3 * 1024 * 1024) { $error_msg = 'حجم الصورة يجب ألا يتجاوز 3 ميجابايت.'; }
        else {
            $info = @getimagesize($file['tmp_name']);
            $mime = $info['mime'] ?? '';
            $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!$info || !isset($extensions[$mime])) { $error_msg = 'الصيغ المدعومة: JPG وPNG وWEBP فقط.'; }
            else {
                $dir = UPLOAD_PATH . 'avatars/'; if (!is_dir($dir)) mkdir($dir, 0755, true);
                $filename = 'user_' . $user_id . '_' . bin2hex(random_bytes(8)) . '.' . $extensions[$mime];
                if (move_uploaded_file($file['tmp_name'], $dir . $filename)) {
                    $q = $pdo->prepare('UPDATE users SET avatar=? WHERE id=?'); $q->execute([$filename,$user_id]);
                    $success_msg = 'تم تحديث صورتك الشخصية.';
                } else { $error_msg = 'تعذر حفظ الصورة، حاول مرة أخرى.'; }
            }
        }
    }
}


// معالجة تغيير حالة الإعلان (تم البيع / حذف)
if (isset($_GET['action'], $_GET['listing_id'])) {
    $action     = sanitize($_GET['action']);
    $listing_id = filter_var($_GET['listing_id'], FILTER_VALIDATE_INT);

    if ($action === 'mark_sold') {
        $stmt = $pdo->prepare("UPDATE listings SET status = 'sold' WHERE id = ? AND user_id = ?");
        $stmt->execute([$listing_id, $user_id]);
        $success_msg = "تم تحديث حالة الإعلان إلى (تم البيع).";
    } elseif ($action === 'delete') {
        $stmt = $pdo->prepare("UPDATE listings SET status = 'deleted' WHERE id = ? AND user_id = ?");
        $stmt->execute([$listing_id, $user_id]);
        $success_msg = "تم نقل الإعلان إلى المحذوفات.";
    }
}

// جلب بيانات المستخدم
$u_stmt = $pdo->prepare("SELECT u.*, s.name as state_name FROM users u LEFT JOIN states s ON u.state_id = s.id WHERE u.id = ?");
$u_stmt->execute([$user_id]);
$user = $u_stmt->fetch();

// جلب إعلانات المستخدم
$l_stmt = $pdo->prepare("SELECT l.*, c.name as category_name,
        (SELECT image_path FROM listing_images WHERE listing_id = l.id ORDER BY is_primary DESC LIMIT 1) as primary_image
        FROM listings l
        JOIN categories c ON l.category_id = c.id
        WHERE l.user_id = ? AND l.status != 'deleted'
        ORDER BY l.id DESC");
$l_stmt->execute([$user_id]);
$my_listings = $l_stmt->fetchAll();
?>

<div class="container py-4">
    <?php if ($error_msg): ?><div class="alert alert-danger"><?=sanitize($error_msg)?></div><?php endif; ?>
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4"><?= $success_msg ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- كارت البيانات الشخصية -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-4 text-center">
                <div class="mb-3"><img class="profile-avatar" src="<?= !empty($user['avatar']) && $user['avatar'] !== 'default_avatar.png' ? BASE_URL . 'uploads/avatars/' . rawurlencode($user['avatar']) : BASE_URL . 'assets/img/avatar-placeholder.svg' ?>" alt="الصورة الشخصية"></div>
                <form method="post" enctype="multipart/form-data" class="mb-3"><input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>"><input type="hidden" name="action" value="update_avatar"><label class="btn btn-outline-dark btn-sm">تغيير الصورة<input type="file" name="avatar" accept="image/jpeg,image/png,image/webp" hidden onchange="this.form.submit()"></label><small class="d-block text-muted mt-2">JPG أو PNG أو WEBP · حتى 3MB</small></form>
                <h5 class="fw-bold mb-1"><?= sanitize($user['full_name']) ?></h5>
                <p class="text-muted small mb-2"><i class="me-1" data-lucide="phone"></i><?= sanitize($user['phone']) ?></p>
                <p class="text-muted small"><i class="me-1" data-lucide="map-pin"></i><?= $user['state_name'] ?? 'غير محدد' ?></p>
                <hr>
                <a href="favorites.php" class="btn btn-outline-danger w-100 fw-bold"><i class="me-1" data-lucide="heart"></i> الإعلانات المفضلة</a>
            </div>
        </div>

        <!-- قائمة إعلاناتي -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-3 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold mb-0"><i class="me-2 text-primary" data-lucide="list-checks"></i>إعلاناتي الخاصة</h5>
                    <a href="add-listing.php" class="btn btn-warning btn-sm fw-bold"><i class="me-1" data-lucide="plus"></i> إعلان جديد</a>
                </div>

                <?php if (empty($my_listings)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="display-4 d-block mb-2" data-lucide="inbox"></i>
                        لم تقم بنشر أي إعلانات بعد.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>الصورة</th>
                                    <th>عنوان الإعلان</th>
                                    <th>السعر</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($my_listings as $item): ?>
                                    <tr>
                                        <td style="width: 70px;">
                                            <img src="<?= $item['primary_image'] ? BASE_URL . 'uploads/listings/' . $item['primary_image'] : 'https://via.placeholder.com/60' ?>" class="rounded" style="width: 60px; height: 50px; object-fit: cover;">
                                        </td>
                                        <td>
                                            <a href="listing-details.php?id=<?= $item['id'] ?>" class="fw-bold text-dark text-decoration-none d-block text-truncate" style="max-width: 200px;"><?= sanitize($item['title']) ?></a>
                                            <small class="text-muted"><?= $item['category_name'] ?></small>
                                        </td>
                                        <td class="text-success fw-bold"><?= number_format($item['price']) ?> SDG</td>
                                        <td>
                                            <?php if ($item['status'] === 'active'): ?>
                                                <span class="badge bg-success">نشط</span>
                                            <?php elseif ($item['status'] === 'sold'): ?>
                                                <span class="badge bg-secondary">تم البيع</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-light border" type="button" data-bs-toggle="dropdown"><i class="" data-lucide="ellipsis-vertical"></i></button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li><a class="dropdown-item" href="edit-listing.php?id=<?= $item['id'] ?>"><i class="me-2" data-lucide="pencil"></i>تعديل</a></li>
                                                    <?php if ($item['status'] === 'active'): ?>
                                                        <li><a class="dropdown-item text-success" href="profile.php?action=mark_sold&listing_id=<?= $item['id'] ?>"><i class="me-2" data-lucide="circle-check"></i>تعيين كـ تم البيع</a></li>
                                                    <?php endif; ?>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li><a class="dropdown-item text-danger" href="profile.php?action=delete&listing_id=<?= $item['id'] ?>" onclick="return confirm('هل أنت تأكد من حذف الإعلان؟')"><i class="me-2" data-lucide="trash-2"></i>حذف الإعلان</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
