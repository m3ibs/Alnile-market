<?php
$pageTitle = "إنشاء حساب جديد";
require_once __DIR__ . '/includes/header.php';

$pdo = Database::getInstance();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "رمز الحماية غير صالحة، يرجى إعادة المحاولة.";
    }

    $full_name = sanitize($_POST['full_name'] ?? '');
    $phone     = sanitize($_POST['phone'] ?? '');
    $password  = $_POST['password'] ?? '';
    $state_id  = filter_var($_POST['state_id'] ?? null, FILTER_VALIDATE_INT);

    if (empty($full_name)) $errors[] = "يرجى إدخال الاسم بالكامل.";
    if (empty($phone)) $errors[] = "يرجى إدخال رقم الهاتف.";
    if (strlen($password) < 6) $errors[] = "كلمة المرور يجب أن لا تقل عن 6 خانات.";

    if (empty($errors)) {
        // التحقق من تكرار رقم الهاتف
        $stmt = $pdo->prepare("SELECT id FROM users WHERE phone = ?");
        $stmt->execute([$phone]);
        if ($stmt->fetch()) {
            $errors[] = "رقم الهاتف مسجل بالفعل.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, phone, password, state_id) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$full_name, $phone, $hashed_password, $state_id])) {
                $_SESSION['user_id']   = $pdo->lastInsertId();
                $_SESSION['user_name'] = $full_name;
                $_SESSION['user_role'] = 'user';
                redirect('');
            } else {
                $errors[] = "حدث خطأ أثناء إنشاء الحساب.";
            }
        }
    }
}

$states = $pdo->query("SELECT * FROM states ORDER BY name ASC")->fetchAll();
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-body p-4">
                    <h4 class="card-title text-center mb-4 font-weight-bold">إنشاء حساب جديد</h4>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger py-2">
                            <ul class="mb-0 ps-3">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= $error ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

                        <div class="mb-3">
                            <label class="form-label">الاسم بالكامل</label>
                            <input type="text" name="full_name" class="form-control" required value="<?= $full_name ?? '' ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف (واتساب / اتصال)</label>
                            <input type="text" name="phone" class="form-control" placeholder="0912345678" required value="<?= $phone ?? '' ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">الولاية</label>
                            <select name="state_id" class="form-select">
                                <option value="">اختر الولاية...</option>
                                <?php foreach ($states as $st): ?>
                                    <option value="<?= $st['id'] ?>"><?= $st['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2">تسجيل الحساب</button>
                    </form>

                    <div class="text-center mt-3">
                        <small class="text-muted">لديك حساب بالفعل؟ <a href="login.php">سجل الدخول هنا</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
