/* سوق النيل: lightweight offline/static cache. Private pages are never cached. */
const CACHE_VERSION = 'nile-static-v2';
const STATIC_FILES = [
  './assets/css/style.css',
  './assets/js/main.js',
  './assets/js/bootstrap-lite.js',
  './assets/img/logo.png',
  './assets/img/avatar-placeholder.svg',
  './assets/img/no-image.svg'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_VERSION).then(cache => cache.addAll(STATIC_FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('nile-') && key !== CACHE_VERSION).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  const path = url.pathname;
  if (/\/(admin|ajax)\//.test(path) || /\/(login|logout|register|profile|favorites|add-listing|edit-listing)\.php$/.test(path)) return;
  if (/\.(css|js|png|jpe?g|webp|svg|ico|woff2?)$/i.test(path)) {
    event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
      if (response.ok) { const copy = response.clone(); caches.open(CACHE_VERSION).then(cache => cache.put(request, copy)); }
      return response;
    })));
    return;
  }
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      if (response.ok && (path.endsWith('/index.php') || path.endsWith('/'))) {
        const copy = response.clone(); caches.open(CACHE_VERSION).then(cache => cache.put(request, copy));
      }
      return response;
    }).catch(() => caches.match(request).then(cached => cached || caches.match('./index.php'))));
  }
});
