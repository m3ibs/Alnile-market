-- إدراج الأقسام الرئيسية
INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `sort_order`) VALUES
(1, 'السيارات والمركبات', 'vehicles', 'bi-car-front', 1),
(2, 'العقارات للبيع', 'real-estate-sale', 'bi-house-door', 2),
(3, 'العقارات للإيجار', 'real-estate-rent', 'bi-key', 3),
(4, 'سوق النساء', 'women-market', 'bi-bag-heart', 4),
(5, 'الملابس الرجالية', 'men-clothes', 'bi-person', 5),
(6, 'الهواتف والأجهزة اللوحية', 'phones-tablets', 'bi-phone', 6),
(7, 'الكمبيوتر واللابتوبات', 'computers', 'bi-laptop', 7),
(8, 'الأدوات والمعدات المستعملة', 'used-tools', 'bi-tools', 8);

-- إدراج عينات من الولايات والمدن والأحياء السودانية
INSERT INTO `states` (`id`, `name`) VALUES
(1, 'ولاية نهر النيل'),
(2, 'ولاية البحر الأحمر'),
(3, 'ولاية الخرطوم');

INSERT INTO `cities` (`id`, `state_id`, `name`) VALUES
(1, 1, 'شندي'),
(2, 1, 'عطبرة'),
(3, 2, 'بورتسودان'),
(4, 3, 'أم درمان');

INSERT INTO `neighborhoods` (`id`, `city_id`, `name`) VALUES
(1, 1, 'حي الموردة'),
(2, 1, 'حي مربع 11'),
(3, 2, 'حي الداخليات'),
(4, 3, 'ديم المدنية'),
(5, 4, 'حي العباسية');
